#include <iostream>
#include "shape.h"
using namespace std;

//class Shape{
//
//private:
//    int height;
//
//protected:
//    int width;
//
//public:
//
//    Shape()
//    {
//        height = width = 0;
//    }
//
//    Shape(int h, int w)
//    {
//        height = h;
//        width = w;
//    }
//
//    void setHeight(int h)
//    {
//        height = h;
//    }
//
//    void setWidth(int w)
//    {
//        width = w;
//    }
//
//    int getWidth()
//    {
//        return width;
//    }
//
//    int getHeight()
//    {
//        return height;
//    }
//
//    int getArea()
//    {
//        return height * width;
//    }
//
//};

int main()
{
//    Shape shape1;
//    shape1.setHeight(10);
//    shape1.setWidth(5);
//    cout<<"The area of the shape 1 is: "<<shape1.getArea()<<endl;
//
//    Shape shape2;
//    shape2.setHeight(20);
//    shape2.setWidth(10);
//    cout<<"The area of the shape 2 is: "<<shape2.getArea()<<endl;
//
//    Shape shape[5];
//    shape[0].setHeight(5);
//    shape[0].setWidth(2);
//    cout<<"The area of the shape is: "<<shape[0].getArea()<<endl;
//
//    shape[1].setHeight(5);
//    shape[1].setWidth(2);
//    cout<<"The area of the shape is: "<<shape[1].getArea()<<endl;
//
//    cout<<shape[2].getArea()<<endl;
//
//    Shape sh;
//    cout<<sh.getArea()<<endl;

    Shape sh(10,5);
    cout<<sh.getArea()<<endl;

    Shape sh1[5];
    return 0;
}

#ifndef SHAPE_H
#define SHAPE_H


class Shape
{
    public:
        Shape();
        Shape(int, int);

        void setArea(int);

        int getArea();
        int Getwidth();
        void Setwidth(int);
        int Getheight();
        void Setheight(int);
    protected:

    private:
        int width;
        int height;
        int area;
};

#endif // SHAPE_H

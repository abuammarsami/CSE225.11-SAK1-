#include "shape.h"

Shape::Shape()
{
    height = width = 0;

}

Shape::Shape(int h, int w)
{
    height = h;
    width = w;
}

int Shape::getArea()
{
    return height * width;
}

int Shape::Getwidth()
{
    return width;
}


void Shape::Setwidth(int w)
{
    width = w;
}

int Shape::Getheight()
{
    return height;
}

void Shape::Setheight(int h)
{
    height = h;
}



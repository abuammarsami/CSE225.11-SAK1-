#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include <string>


class studentInfo
{
    public:
        studentInfo();
        ~studentInfo();
        bool operator!=(studentInfo);
        bool operator==(studentInfo);
    protected:

    private:
};

#endif // STUDENTINFO_H

#include "studentinfo.h"

studentInfo::studentInfo()
{
    //ctor
}

studentInfo::~studentInfo()
{
    //dtor
}
